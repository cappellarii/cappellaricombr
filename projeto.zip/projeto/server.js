const express = require("express");
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const sqlite3 = require("sqlite3").verbose();
const app = express();

const uploadsDir = path.join(__dirname, "public", "uploads");

if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

const allowedMimeTypes = new Set([
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
    "image/bmp",
    "image/svg+xml",
    "video/mp4",
    "video/webm",
    "video/quicktime",
    "video/x-matroska-3d",
    "video/mkv",
    "video/matroska",
    "application/x-matroska",
    "video/x-matroska",
    "video/ogg",
    "application/pdf",
    "application/zip",
    "application/x-zip-compressed",
    "application/x-rar-compressed",
    "application/x-7z-compressed",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/json",
    "application/octet-stream",
    "text/plain",
    "text/csv"
]);

const allowedFileExtensions = new Set([
    ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".svg",
    ".mp4", ".webm", ".mov", ".mkv", ".ogv",
    ".pdf", ".zip", ".rar", ".7z",
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".txt", ".csv", ".json"
]);

const uploadStorage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
        const safeOriginal = path.basename(file.originalname || "arquivo");
        const ext = path.extname(safeOriginal).slice(0, 15);
        const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
        cb(null, `${unique}${ext}`);
    }
});

const upload = multer({
    storage: uploadStorage,
    fileFilter: (_req, file, cb) => {
        const mime = String(file.mimetype || "").toLowerCase();
        const ext = path.extname(file.originalname || "").toLowerCase();

        if (allowedMimeTypes.has(mime) || allowedFileExtensions.has(ext)) {
            return cb(null, true);
        }

        return cb(new Error("Tipo de arquivo não permitido"));
    }
});

app.use(express.json());
app.use(express.static("public"));
app.use("/uploads", express.static(uploadsDir));

// banco
const db = new sqlite3.Database("messages.db");

function ensureSchema(callback) {
    db.serialize(() => {
        db.run(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT DEFAULT 'Anonimo',
            text TEXT,
            file_url TEXT,
            file_name TEXT,
            file_mime TEXT,
            file_size INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        `);

        db.all("PRAGMA table_info(messages)", (err, columns) => {
            if (err) {
                return callback(err);
            }

            const existingColumns = new Set(columns.map((column) => column.name));
            const requiredColumns = [
                { name: "name", sql: "ALTER TABLE messages ADD COLUMN name TEXT DEFAULT 'Anonimo'" },
                { name: "file_url", sql: "ALTER TABLE messages ADD COLUMN file_url TEXT" },
                { name: "file_name", sql: "ALTER TABLE messages ADD COLUMN file_name TEXT" },
                { name: "file_mime", sql: "ALTER TABLE messages ADD COLUMN file_mime TEXT" },
                { name: "file_size", sql: "ALTER TABLE messages ADD COLUMN file_size INTEGER" }
            ];

            const pending = requiredColumns.filter((column) => !existingColumns.has(column.name));

            if (pending.length === 0) {
                return callback(null);
            }

            let pendingCount = pending.length;
            let failed = false;

            pending.forEach((column) => {
                db.run(column.sql, (alterErr) => {
                    if (failed) {
                        return;
                    }

                    if (alterErr) {
                        failed = true;
                        return callback(alterErr);
                    }

                    pendingCount -= 1;

                    if (pendingCount === 0) {
                        callback(null);
                    }
                });
            });
        });
    });
}

// pegar mensagens
app.get("/messages", (req, res) => {
    const parsedLimit = Number.parseInt(req.query.limit, 10);
    const limit = Number.isFinite(parsedLimit)
        ? Math.min(Math.max(parsedLimit, 1), 200)
        : 50;

    const parsedBeforeId = Number.parseInt(req.query.beforeId, 10);
    const parsedAfterId = Number.parseInt(req.query.afterId, 10);
    const hasBeforeId = Number.isFinite(parsedBeforeId) && parsedBeforeId > 0;
    const hasAfterId = Number.isFinite(parsedAfterId) && parsedAfterId >= 0;

    if (hasAfterId) {
        return db.all(
            "SELECT * FROM messages WHERE id > ? ORDER BY id ASC LIMIT ?",
            [parsedAfterId, limit],
            (err, rows) => {
                if (err) {
                    return res.status(500).json({ error: "Erro ao buscar mensagens" });
                }

                res.json(rows);
            }
        );
    }

    if (hasBeforeId) {
        return db.all(
            "SELECT * FROM messages WHERE id < ? ORDER BY id DESC LIMIT ?",
            [parsedBeforeId, limit],
            (err, rows) => {
                if (err) {
                    return res.status(500).json({ error: "Erro ao buscar mensagens" });
                }

                res.json(rows.reverse());
            }
        );
    }

    db.all(
        `
        SELECT * FROM (
            SELECT * FROM messages ORDER BY id DESC LIMIT ?
        ) ORDER BY id ASC
        `,
        [limit],
        (err, rows) => {
            if (err) {
                return res.status(500).json({ error: "Erro ao buscar mensagens" });
            }

            res.json(rows);
        }
    );
});

// enviar mensagem com texto e/ou anexo
app.post("/messages", (req, res) => {
    upload.single("file")(req, res, (uploadErr) => {
        if (uploadErr) {
            if (uploadErr instanceof multer.MulterError && uploadErr.code === "LIMIT_FILE_SIZE") {
                return res.status(400).send("Arquivo excede o limite permitido pelo servidor");
            }

            return res.status(400).send(uploadErr.message || "Falha no upload");
        }

        const text = String(req.body?.text || "").trim();
        const cleanName = String(req.body?.name || "").trim();
        const file = req.file;

        if (!cleanName || cleanName.length > 30) {
            if (file?.path) {
                fs.unlink(file.path, () => {});
            }

            return res.status(400).send("Nome inválido");
        }

        if (!text && !file) {
            return res.status(400).send("Envie texto, arquivo ou ambos");
        }

        if (text.length > 1000) {
            if (file?.path) {
                fs.unlink(file.path, () => {});
            }

            return res.status(400).send("Texto muito longo");
        }

        const fileUrl = file ? `/uploads/${file.filename}` : null;
        const fileName = file ? path.basename(file.originalname || "arquivo") : null;
        const fileMime = file ? file.mimetype : null;
        const fileSize = file ? file.size : null;

        db.run(
            "INSERT INTO messages (name, text, file_url, file_name, file_mime, file_size) VALUES (?, ?, ?, ?, ?, ?)",
            [cleanName, text || null, fileUrl, fileName, fileMime, fileSize],
            function insertCallback(err) {
                if (err) {
                    if (file?.path) {
                        fs.unlink(file.path, () => {});
                    }

                    return res.status(500).send("Erro ao salvar mensagem");
                }

                res.status(200).json({ id: this.lastID });
            }
        );
    });
});

ensureSchema((schemaErr) => {
    if (schemaErr) {
        console.error("Erro ao preparar banco:", schemaErr.message);
        process.exit(1);
    }

    app.listen(443, () => {
        console.log("Servidor rodando em http://localhost:443");
    });
});